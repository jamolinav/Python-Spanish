from django.shortcuts import render, redirect
from .models import League, Team, Player

from . import team_maker

def index(request):
	context = {
		"leagues": League.objects.all(),
		"teams": Team.objects.all(),
		"players": Player.objects.all(),
		"all_task" : {
			"Ligas de Béisbol" : League.objects.filter(name__contains='Baseball'),
			"Ligas de Mujeres": League.objects.filter(name__contains='Women'),
			"Ligas de Hockey": League.objects.filter(name__contains='Hockey'),
			"Ligas excepto Football": League.objects.exclude(name__contains='Football'),
			"Ligas Conferencias": League.objects.filter(name__contains='Conference'),
			"Ligas de Atlantico": League.objects.filter(teams=Team.objects.filter(location='Atlantic').first()),
			"Equipos en Dallas": Team.objects.filter(location='Dallas'),
			"Equipos Raptors": Team.objects.filter(team_name__contains='Raptors'),
			"Equipos Ciudad": Team.objects.filter(location__contains='City'),
			"Equipos comienzan con T": Team.objects.filter(team_name__startswith='T'),
			"Equipos ordenados ubicacion": Team.objects.all().order_by('location'),
			"Equipos ordenados descendente": Team.objects.all().order_by('team_name').reverse(),
			"Jugador Cooper": Player.objects.filter(last_name='Cooper'),
			"Jugador Joshua": Player.objects.filter(first_name='Joshua'),
			"Jugador Cooper excepto Joshua": Player.objects.filter(last_name='Cooper').exclude(first_name='Joshua'),
			"Jugador Alexander o Wyatt": Player.objects.filter(first_name='Alexander') | Player.objects.filter(first_name='Wyatt'),
		}
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")