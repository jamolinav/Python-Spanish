from django.shortcuts import render, redirect
from sql_to_orm_app.models import *
# Create your views here.

def index(request):
    context = {
        'books' : Book.objects.all()
    }
    return render(request, 'index.html', context)

def add_book(request):
    print(request.POST)
    Book.objects.create(title=request.POST['title'], desc=request.POST['description'])
    return redirect('/')

def view_book(request, id):
    print(request.GET)
    print('id', id)
    context = {
        'book' : Book.objects.get(id=id),
        'authors' : Author.objects.filter(books=Book.objects.get(id=id)),
        'all_authors' : Author.objects.exclude(books=Book.objects.get(id=id))
    }
    return render(request, 'view_book.html', context)

def add_author(request):
    print(request.POST)
    book_id = request.POST['book_id']
    author_id = request.POST['author_id']
    if int(author_id) != 0:
        author = Author.objects.get(id=author_id)
        author.books.add(Book.objects.get(id=book_id))
    return redirect(f'/books/{book_id}')

def authors(request):
    context = {
        'authors' : Author.objects.all()
    }
    return render(request, 'authors.html', context)

def new_author(request):
    print(request.POST)
    Author.objects.create(first_name=request.POST['first_name'], last_name=request.POST['last_name'],notas=request.POST['notas'])
    return redirect('/authors')

def view_author(request, id):
    print(request.GET)
    print('id', id)
    context = {
        'author' : Author.objects.get(id=id),
        'books' : Book.objects.filter(authors=Author.objects.get(id=id)),
        'all_books' : Book.objects.exclude(authors=Author.objects.get(id=id))
    }
    return render(request, 'view_author.html', context)

def add_book(request):
    print(request.POST)
    book_id = request.POST['book_id']
    author_id = request.POST['author_id']
    if int(book_id) != 0:
        book = Book.objects.get(id=book_id)
        book.authors.add(Author.objects.get(id=author_id))
    return redirect(f'/authors/{author_id}')