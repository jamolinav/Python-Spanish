from django.db import models

# Create your models here.
class dojo(models.Model):
    name    = models.CharField(max_length=255)
    city    = models.CharField(max_length=255)
    state   = models.CharField(max_length=2)
    desc    = models.CharField(max_length=255, default='dojo antiguo')

class ninja(models.Model):
    first_name  = models.CharField(max_length=255)
    last_name   = models.CharField(max_length=255)
    dojo        = models.ForeignKey(dojo, related_name='ninjas', on_delete=models.CASCADE)

class Movie(models.Model):
    title       = models.CharField(max_length=45)
    description = models.TextField()
    release_date = models.DateTimeField()
    duration    = models.IntegerField()
    created_at  = models.DateTimeField(auto_now_add=True)
    updated_at  = models.DateTimeField(auto_now=True)

    def __repr__(self):
        return f'<Movie object: {self.title} ({self.id})>'

class Wizard(models.Model):
    name    = models.CharField(max_length=45)
    house   = models.CharField(max_length=45)
    pet     = models.CharField(max_length=45)
    year    = models.IntegerField()

class Book(models.Model):
	title       = models.CharField(max_length=255)
	created_at  = models.DateTimeField(auto_now_add=True)
	updated_at  = models.DateTimeField(auto_now=True)
	desc        = models.TextField(default='')

class Author(models.Model):
    first_name  = models.CharField(max_length=45)
    last_name   = models.CharField(max_length=45)
    created_at  = models.DateTimeField(auto_now_add=True)
    updated_at  = models.DateTimeField(auto_now=True)
    books       = models.ManyToManyField(Book, related_name='authors')
    notas       = models.CharField(max_length=255, default='')

class Publisher(models.Model):
	name    = models.CharField(max_length=255)
	books   = models.ManyToManyField(Book, related_name="publishers")
	created_at  = models.DateTimeField(auto_now_add=True)
	updated_at  = models.DateTimeField(auto_now=True)
