from django.shortcuts import render, redirect
from django.db.models import Avg, Count, Min, Sum, Q
from .models import League, Team, Player

from . import team_maker

def index(request):
	context = {
		"all_task" : {
			"1. Equipos de Atlantic Soccer Conference" 
				: Team.objects.filter(league__in=League.objects.filter(name='Atlantic Soccer Conference')),
			"2. Jugadores (actuales) en los Boston Penguins" 
				: Player.objects.filter(curr_team__in=Team.objects.filter(location='Boston').filter(team_name='Penguins')),
			"3. Jugadores (actuales) en la International Collegiate Baseball Conference" 
				: Player.objects.filter(curr_team__in=Team.objects.filter(league__in=League.objects.filter(name='International Collegiate Baseball Conference'))),
			"4. Jugadores (actuales) en la Conferencia Americana de Fútbol Amateur con el apellido \"López\""
				: Player.objects.filter(curr_team__in=Team.objects.filter(league__in=League.objects.filter(name='Conferencia Americana de Fútbol Amateur'))).filter(last_name='López'),
			"5. Todos los jugadores de fútbol" 
				: Player.objects.all(),
			"6. Todos los equipos con un jugador (actual) llamado \"Sophia\"" 
				: Team.objects.filter(curr_players__in=Player.objects.filter(first_name='Sophia')),
			"7. Todos las Ligas con un jugador (actual) llamado \"Sophia\"" 
				: League.objects.filter(teams__in=Team.objects.filter(curr_players__in=Player.objects.filter(first_name='Sophia'))),
			"8. Todos con el apellido \"Flores\" que NO (actualmente) juegan para los Washington Roughriders" 
				: Player.objects.exclude(all_teams__in=Team.objects.filter(location='Washington').filter(team_name='Roughriders')).filter(last_name='Flores'),
			"9. Todos los equipos, pasados y presentes, con los que Samuel Evans ha jugado" 
				: Team.objects.filter(all_players__in=Player.objects.filter(first_name='Samuel').filter(last_name='Evans')),
			"10. Todos los jugadores, pasados y presentes, con los gatos tigre de Manitoba" 
				: Player.objects.filter(all_teams__in=Team.objects.filter(location='Manitoba').filter(team_name='CatTiger')),
			"11. todos los jugadores que anteriormente estaban (pero que no lo están) con los Wichita Vikings" 
				: Player.objects.filter(all_teams__in=Team.objects.filter(team_name='Vikings').filter(location='Wichita')).exclude(curr_team__in=Team.objects.filter(team_name='Vikings').filter(location='Wichita')),
			"12. Cada equipo para el que Jacob Gray jugó antes de unirse a los Oregon Colts" 
				: Team.objects.filter(all_players__in=Player.objects.filter(first_name='Jacob').filter(last_name='Gray')).exclude(id__in=Team.objects.filter(team_name='Colts').filter(location='Oregon')),
			"13. Todos llamados \"Joshua\" que alguna vez han jugado en la Federación Atlántica de Jugadores de Béisbol Amateur"
				: Player.objects.filter(first_name='Joshua').filter(all_teams__in=Team.objects.filter(league__in=League.objects.filter(name='Federación Atlántica de Jugadores de Béisbol Amateur'))),
			"14. Todos los equipos que han tenido 12 o más jugadores, pasados y presentes."
				: Team.objects.annotate(total=Count('all_players')).filter(total__gt=12).order_by('team_name'),		
			"15. Todos los jugadores y el número de equipos para los que jugó, ordenados por la cantidad de equipos para los que han jugado." 
				: Player.objects.annotate(total_de_equipos=Count('all_teams')).order_by('total_de_equipos'),
		}
	}
	return render(request, "leagues/index.html", context)

def sports_orm_1(request):
	context = {
		"leagues": League.objects.all(),
		"teams": Team.objects.all(),
		"players": Player.objects.all(),
		"all_task" : {
			"Ligas de Béisbol" : League.objects.filter(name__contains='Baseball'),
			"Ligas de Mujeres": League.objects.filter(name__contains='Women'),
			"Ligas de Hockey": League.objects.filter(name__contains='Hockey'),
			"Ligas excepto Football": League.objects.exclude(name__contains='Football'),
			"Ligas Conferencias": League.objects.filter(name__contains='Conference'),
			"Ligas de Atlantico": League.objects.filter(teams=Team.objects.filter(location='Atlantic').first()),
			"Equipos en Dallas": Team.objects.filter(location='Dallas'),
			"Equipos Raptors": Team.objects.filter(team_name__contains='Raptors'),
			"Equipos Ciudad": Team.objects.filter(location__contains='City'),
			"Equipos comienzan con T": Team.objects.filter(team_name__startswith='T'),
			"Equipos ordenados ubicacion": Team.objects.all().order_by('location'),
			"Equipos ordenados descendente": Team.objects.all().order_by('team_name').reverse(),
			"Jugador Cooper": Player.objects.filter(last_name='Cooper'),
			"Jugador Joshua": Player.objects.filter(first_name='Joshua'),
			"Jugador Cooper excepto Joshua": Player.objects.filter(last_name='Cooper').exclude(first_name='Joshua'),
			"Jugador Alexander o Wyatt": Player.objects.filter(first_name='Alexander') | Player.objects.filter(first_name='Wyatt'),
		}
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")