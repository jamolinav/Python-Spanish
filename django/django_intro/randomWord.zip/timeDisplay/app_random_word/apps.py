from django.apps import AppConfig


class AppRandomWordConfig(AppConfig):
    name = 'app_random_word'
