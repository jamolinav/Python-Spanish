from django.apps import AppConfig


class AppTimeDisplayConfig(AppConfig):
    name = 'app_time_display'
